package com.bunev.sample.basepage;

import com.bunev.sample.infrastructure.driver.Setup;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Base page. Inherit it if you create new Page object so you will have access to driver and wait
 */
public class BasePage {

    protected WebDriver driver;
    protected WebDriverWait wait;

    public BasePage() {
        this.driver = Setup.driver;
        this.wait = Setup.wait;
    }
}
